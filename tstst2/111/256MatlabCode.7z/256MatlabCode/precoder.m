function [Precoded] = precoder(PrePrecoder,NumBsAntenna,PrecodeScheme)
if strcmp(PrecodeScheme,'DFT')
    D = dftmtx(NumBsAntenna)/sqrt(NumBsAntenna);
    N = size(PrePrecoder,1);
    Dpre = D(:,2:N+1);
%       Dpre=ones(16,1);
    Precoded = Dpre*PrePrecoder;
end
end