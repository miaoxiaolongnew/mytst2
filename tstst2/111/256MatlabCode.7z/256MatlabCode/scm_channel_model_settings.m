%����SCM�ŵ�����ز���
function [Scmpar,Linkpar,Antpar]=scm_channel_model_settings(TxAntNum,RxAntNum,ActiveUE)

dt = 0.5;                                 % BS antenna elements positions
dr = 0.5;

NUM_users = ActiveUE;
NUM_timesamples = 1;
NUM_paths = 6;

CarrierFreq = 4e9;                                                    % Carrier frequency
Velocity = 1;                                                         % MS moving velocity in m/s
SampleDensity = 1*(3e8/CarrierFreq/2/Velocity)/0.5e-3;                % 0.5ms
DelaySamplingInterval = (1/30.72e6);                                  % delay sampling grid

antpar = antparset;
antpar.BsElementPosition = dt;
antpar.MsElementPosition = dr;
Antpar = antpar;

scmpar = scmparset;
scmpar.NumBsElements = TxAntNum;
scmpar.NumMsElements = RxAntNum;
scmpar.Scenario = 'suburban_macro';	                                   % SCM scenario
% scmpar.Scenario = 'urban_macro';
% scmpar.Scenario = 'urban_micro';
scmpar.NumPaths = NUM_paths;
scmpar.NumTimeSamples = NUM_timesamples;
scmpar.SampleDensity = SampleDensity;
scmpar.DelaySamplingInterval = DelaySamplingInterval;
Scmpar = scmpar;

linkpar = linkparset(NUM_users);                                      % generate number of links
linkpar.MsVelocity = Velocity*ones(1,NUM_users);
Linkpar = linkpar;