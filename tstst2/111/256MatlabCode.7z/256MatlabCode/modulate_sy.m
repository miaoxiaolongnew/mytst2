function [DataModulated] = modulate_sy(DataRawI,Modulation)
LengthData = length(DataRawI);

  % BPSK modulation
if strcmp(Modulation,'BPSK')
    scale=1/1;
    M_order =1;
   % QPSK modulation
elseif strcmp(Modulation,'QPSK')  
    scale=1/sqrt(2);
    M_order =2; 
    % 16-QAM modulation
elseif strcmp(Modulation,'16QAM')
    scale=1/sqrt(10);
    M_order =4;  
   % 64-QAM modulation
elseif strcmp(Modulation,'64QAM')%---zhy---64QAM理解类似16QAM
    scale=1/sqrt(42);
    M_order =6;  
end


    UM_Symbles_T=reshape(DataRawI,[],M_order);
    UM_Symbles=bi2de(UM_Symbles_T,2,'left-msb');
    DataModulated = scale*qammod(UM_Symbles, 2^M_order);

end