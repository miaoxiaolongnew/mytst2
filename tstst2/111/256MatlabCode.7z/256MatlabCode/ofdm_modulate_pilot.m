function [PilotOfdmModulated] = ofdm_modulate_pilot(PilotI,FFTSize,CP_Len)
PilotPreOfdm = zeros(1,FFTSize);
for i = 1:464
    PilotPreOfdm(i) = 0;
end
for i = 465:465+3168/2-1
    PilotPreOfdm(i) = PilotI(i-464);
end
PilotPreOfdm(2049) = 0;
for i = 2050:2050+3168/2-1
    PilotPreOfdm(i) = PilotI(i-465);
end
for i = 3634:4096
    PilotPreOfdm(i) = 0;
end
PilotPreCP = ifft(PilotPreOfdm,FFTSize);
PilotOfdmModulated = [PilotPreCP(4096-CP_Len+1:4096) PilotPreCP];

end