function [DataOfdmModulated] = ofdm_modulate_data(DataModulated,FFTSize,CP_Len)
DataPreOfdm = zeros(1,FFTSize);
for i = 1:464
    DataPreOfdm(i) = 0;
end
for i = 465:465+3168/2-1
    DataPreOfdm(i) = DataModulated(i-464);
end
DataPreOfdm(2049) = 0;
for i = 2050:2050+3168/2-1
    DataPreOfdm(i) = DataModulated(i-465);
end
for i = 3634:4096
    DataPreOfdm(i) = 0;
end
DataPreCP = ifft(DataPreOfdm,FFTSize);
DataOfdmModulated = [DataPreCP(4096-CP_Len+1:4096) DataPreCP];

end