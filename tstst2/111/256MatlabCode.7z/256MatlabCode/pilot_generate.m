function [PilotUserI] = pilot_generate(UE_ID_i,TotalUE,PilotTotal)
N=length(PilotTotal);
PilotUserI = zeros(1,N);
for i = 1:N
    ID = mod(i,TotalUE);
    if ID==0
        ID=12;
    end
    if ID ~= UE_ID_i+1
        PilotUserI(i) = 0;
    else
        PilotUserI(i) = PilotTotal(i);
    end    
end
end