function BER=CalculateBER_sy(DataRecover,DataRaw,UE_ID,NumDataSymb,NumSubcarriers,Modulation,State)

xhat=zeros(length(UE_ID),size(DataRecover,2));
if State==0
    for i=1:length(UE_ID)
             xhat(i,:) = DataRecover((UE_ID(i)+1),:);
    end
else
    for i=1:length(UE_ID)
             xhat(i,:) = DataRecover(i,:);
    end
end
    
         BER=zeros(1,12);
          % BPSK modulation
if strcmp(Modulation,'BPSK')
            scale=1/1;
            M_order =1; 
   % QPSK modulation
elseif strcmp(Modulation,'QPSK')
            scale=1/sqrt(2);
            M_order =2; 
elseif strcmp(Modulation,'16QAM')
            scale=1/sqrt(10);
            M_order =4;   
elseif strcmp(Modulation,'64QAM')%---zhy---64QAM理解类似16QAM
            scale=1/sqrt(42);
            M_order =6;   
end


   xhat = qamdemod(xhat/scale,2^M_order);
   for nUE=1:length(UE_ID)
    xhat1=de2bi(xhat(nUE,:),M_order,'left-msb'); 
    xhat1 = reshape(xhat1,1,M_order*NumSubcarriers*NumDataSymb); 
    BER((UE_ID(nUE)+1)) = length(find(DataRaw(nUE,:)~=xhat1))/(M_order*NumSubcarriers*NumDataSymb);

end