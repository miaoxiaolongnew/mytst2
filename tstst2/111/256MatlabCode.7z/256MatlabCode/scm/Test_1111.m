clear;
clc;

N = 2048;
K = 16;

L = 100;
h = randn(L,1) + 1j*randn(L,1);

H = fft(h,N);
% Y = H.*(1/sqrt(2)*(randn(N,1)+1j*randn(N,1)));
Y = H;

Sigma = Y.*conj(Y);
% plot(abs(ifft(Sigma)))

Sigma = Sigma(1:K);
plot(abs(ifft(Sigma)),'b');hold on;
plot(abs(dct(Sigma)/10),'r');hold on;

l = 3;

Tri = [l:-1:1,zeros(1,K-2*l+1),1:l-1];
Tri = [l:-1:1,zeros(1,K-l)];
% Tri = [ones(1,l),zeros(1,K-l)];

% 
% fft(Tri)


DCT_MTX = dctmtx(K);
IDCT_MIX = DCT_MTX';
% DCT_MTX*DCT_MTX'

a = IDCT_MIX*diag(Tri)*DCT_MTX

clc;