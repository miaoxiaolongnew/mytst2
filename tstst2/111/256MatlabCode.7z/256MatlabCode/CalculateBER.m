function BER=CalculateBER(DataRecover,DataRaw,UE_ID,NumDataSymb,NumSubcarriers,Modulation,State)

xhat=zeros(length(UE_ID),size(DataRecover,2));
if State==0
    for i=1:length(UE_ID)
             xhat(i,:) = DataRecover((UE_ID(i)+1),:);
    end
else
    for i=1:length(UE_ID)
             xhat(i,:) = DataRecover(i,:);
    end
end
    
         BER=zeros(1,12);
          % BPSK modulation
if strcmp(Modulation,'BPSK')
   xhat = qamdemod(xhat,2);
   for nUE=1:length(UE_ID)
   xhat1 = dec2bin(xhat(nUE,:)).';
   xhat1 = reshape(xhat1,1,1*NumSubcarriers*NumDataSymb);
   xhat1 = bin2dec(xhat1.').';
   BER((UE_ID(nUE)+1)) = length(find(DataRaw(nUE,:)~=xhat1))/(1*NumSubcarriers*NumDataSymb);
   end
   % QPSK modulation
elseif strcmp(Modulation,'QPSK')
   xhat = qamdemod(xhat*sqrt(2),4);
   for nUE=1:length(UE_ID)
   xhat1 = dec2bin(xhat(nUE,:)).';
   xhat1 = reshape(xhat1,1,2*NumSubcarriers*NumDataSymb);
   xhat1 = bin2dec(xhat1.').';
   BER((UE_ID(nUE)+1)) = length(find(DataRaw(nUE,:)~=xhat1))/(2*NumSubcarriers*NumDataSymb);
   end
elseif strcmp(Modulation,'16QAM')
   xhat = qamdemod(xhat*sqrt(10),16);
   for nUE=1:length(UE_ID)
   xhat1 = dec2bin(xhat(nUE,:)).';
   xhat1 = reshape(xhat1,1,4*NumSubcarriers*NumDataSymb);
   xhat1 = bin2dec(xhat1.').';
   BER((UE_ID(nUE)+1)) = length(find(DataRaw(nUE,:)~=xhat1))/(4*NumSubcarriers*NumDataSymb);
   end
   % 64-QAM modulation
elseif strcmp(Modulation,'64QAM')%---zhy---64QAM��������16QAM
  xhat = qamdemod(xhat*sqrt(42),64); 
  for nUE=1:length(UE_ID)
   xhat1 = dec2bin(xhat(nUE,:)).';
   xhat1 = reshape(xhat1,1,6*NumSubcarriers*NumDataSymb);
   xhat1 = bin2dec(xhat1.').';
   BER((UE_ID(nUE)+1)) = length(find(DataRaw(nUE,:)~=xhat1))/(6*NumSubcarriers*NumDataSymb);
   end
end

end