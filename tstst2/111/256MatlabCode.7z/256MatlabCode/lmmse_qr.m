% ����QR�ֽ��LMMSE
function W = lmmse_qr(H_FreqEstimate,AntennaBS,TotalUE,Sigama)

sigamaI = Sigama*eye(TotalUE);
NumSubBand = size(H_FreqEstimate,2)/TotalUE;
W = cell(1,NumSubBand);
Index = 1;
for i=1:NumSubBand
    H_FreqEstimate_temp = H_FreqEstimate(:,Index:(Index+TotalUE-1));
    H_Extend = [H_FreqEstimate_temp' sigamaI]';
    [Q R] = qr(H_Extend,0);
    Q1 = Q(1:AntennaBS,:);
    Q2 = (1/Sigama)*Q(AntennaBS+1:end,:);
    W{1,i} = Q2 * Q1'; % 12*16
    Index = Index + TotalUE;
end