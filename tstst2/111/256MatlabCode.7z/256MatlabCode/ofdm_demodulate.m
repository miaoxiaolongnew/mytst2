% ȥ��ѭ��ǰ׺��OFDM�����ȡ����Ч���ز�
function ValidSubcarriers = ofdm_demodulate(SignalRec,FFTSize,NumSubcarriers,Type)
[RxAntNum,Symblen] = size(SignalRec);

switch(Type)
    case 'Pilot'
        CpLen = 352;
    case 'Data'
        CpLen = 288;
end

NumOfdmSymb = Symblen/(FFTSize+CpLen);
ValidSubcarriers = zeros(RxAntNum,NumSubcarriers*NumOfdmSymb);
SignalRec_noCP = zeros(RxAntNum,NumOfdmSymb*FFTSize);
start = 1;
for i=1:NumOfdmSymb %ȥ��ѭ��ǰ׺
    SignalRec_noCP_tmp = SignalRec(:,(start+CpLen*i):(start+CpLen*i+FFTSize-1));
    SignalRec_noCP(:,start:(start+FFTSize-1)) = SignalRec_noCP_tmp;
    start = start + FFTSize;
end

for nRx=1:RxAntNum %OFDM�����ȡ����Ч���ز�
    Index1 = 1;
    Index2 = 1;
    for nOfdmSymb=1:NumOfdmSymb
        ValidSubcarriers_temp = fft(SignalRec_noCP(nRx, (Index1:(Index1+FFTSize-1))), FFTSize); %1/sqrt(FFTSize)*
        ValidSubcarriers(nRx,Index2:(Index2+NumSubcarriers-1)) = ValidSubcarriers_temp(:,[465:465+3168/2-1 2050:2050+3168/2-1]);
        Index1 = Index1 + FFTSize;
        Index2 = Index2 + NumSubcarriers;
    end
end


