% LS�ŵ�����
function H_FreqEstimate = LS_channel_estimation(RxFreqPilot,PilotTable)

NumAntBS = size(RxFreqPilot,1); 
for i=1:NumAntBS
    H_FreqEstimate_tmp(i,:) = RxFreqPilot(i,:).*conj(PilotTable);
end
H_FreqEstimate = H_FreqEstimate_tmp;