% Main函数
clc;
close all;
clear all;
addpath('scm');
%%
% 1slot 14个OFDM符号 250us CP：352+288*13
% 1subframe 56个OFDM符号 1ms
%% 参数设置
AntennaBS = 256; %基站端天线数
AntennaUE = 1;  %单天线用户

UE_ID = [0]; %总共12个用户，UE_ID可从0到11
NumUE = length(UE_ID); %当前进行数据传输的用户数
TotalUE = 12; %总共12个用户

Modulation = '16QAM'; %调制方式，可选BPSK，QPSK，16QAM，64QAM
SNR = 30; %信噪比，用于AWGN信道的产生
NumSubcarriers = 3168; %264RB
FFTSize = 4096;
CP_Long = 352;
CP_Short = 288;
[Scmpar,Linkpar,Antpar] = scm_channel_model_settings(AntennaUE,NumUE,AntennaBS);
Sigama = 1; %MSE
[num, txt, raw] = xlsread('pilot.xlsx');  %导入导频数据
PilotTotal = str2double(raw)';
% Guard:0, UL_pilot:1, UL_data:2, DL_pilot:3, DL_data:4
% BS发送帧格式
SlotFormat = [3 4 4 4 4 4 4 4 4 4 4 4 0 0]; 
NumSymbPerSlot = length(SlotFormat);
SimSlotNum = 1; %仿真的帧数
PrecodeScheme = 'DFT'; %预编码矩阵的选择方法
BER_total_uplink = 0;

for iSlot = 1:SimSlotNum
%% 发送端（BS）
NumDataSymb = length(find(SlotFormat==4)); %找出当前帧格式中用于DL_data的OFDM符号数
NumBits = calculate_bits(Modulation,NumSubcarriers,NumDataSymb);
% DataRaw = zero(NumUE,NumBits); %初始化
DataRaw = randi(2,NumUE,NumBits)-1; %产生0，1的比特流
% fid = fopen('..\128MatlabCode_SCM\128MatlabCode\datawriter\data_raw.txt','w');%将数据写入文本文件
% fprintf(fid,'%f\t',DataRaw);
Pilot = zeros(NumUE,NumSubcarriers); %初始化
DataModulated = zeros(NumUE,NumSubcarriers*NumDataSymb); %初始化
for i=1:NumUE   %产生导频符号，并对数据比特流进行调制
    Pilot(i,:) = pilot_generate(UE_ID(i),TotalUE,PilotTotal);
    DataModulated(i,:) = modulate_sy(DataRaw(i,:),Modulation);
end
PilotPrecoded = precoder(Pilot,AntennaBS,PrecodeScheme);
DataPrecoded = precoder(DataModulated,AntennaBS,PrecodeScheme);
PilotOfdmModulated = zeros(AntennaBS,FFTSize+CP_Long); %初始化
DataOfdmModulated = zeros(AntennaBS,(FFTSize+CP_Short)*NumDataSymb); %初始化
for i=1:AntennaBS   %对导频与数据符号进行OFDM调制，并添加循环前缀（CP）
    PilotOfdmModulated(i,:) = ofdm_modulate_pilot(PilotPrecoded(i,:),FFTSize,CP_Long);
    for j=1:NumDataSymb
        DataOfdmModulated(i,(FFTSize+CP_Short)*(j-1)+1:(FFTSize+CP_Short)*j) = ofdm_modulate_data(DataPrecoded(i,NumSubcarriers*(j-1)+1:NumSubcarriers*j),FFTSize,CP_Short);
    end
end


%------------------------------------------------------------------
% %导入实测数据
% data_start = 2940;
% str1_im = load('C:\Users\LXT\Desktop\YX_TST\Mobile_Station\MAT_Data\str1_im.txt'); %第一个用户的数据
% str1_re = load('C:\Users\LXT\Desktop\YX_TST\Mobile_Station\MAT_Data\str1_re.txt');
% NumFracBits = 15;
% str1_im_tmp = str1_im/(2^NumFracBits);
% str1_re_tmp = str1_re/(2^NumFracBits);
% str1 = str1_re_tmp + 1i*str1_im_tmp;
% 
% str2_im = load('C:\Users\LXT\Desktop\YX_TST\Mobile_Station\MAT_Data\str2_im.txt'); %第二个用户的数据
% str2_re = load('C:\Users\LXT\Desktop\YX_TST\Mobile_Station\MAT_Data\str2_re.txt');
% str2_im_tmp = str2_im/(2^NumFracBits);
% str2_re_tmp = str2_re/(2^NumFracBits);
% str2 = str2_re_tmp + 1i*str2_im_tmp;
% 
% PilotOfdmModulated(1,:) = str1(:,(1+data_start):(data_start+FFTSize+160));
% PilotOfdmModulated(2,:) = str2(:,(1+data_start):(data_start+FFTSize+160));
% DataOfdmModulated(1,1:(FFTSize+144)*NumDataSymb) = str1(:,(FFTSize+160+1+data_start):(FFTSize+160+1+(FFTSize+144)*NumDataSymb-1+data_start));
% DataOfdmModulated(2,1:(FFTSize+144)*NumDataSymb) = str2(:,(FFTSize+160+1+data_start):(FFTSize+160+1+(FFTSize+144)*NumDataSymb-1+data_start));

%-----------------------------------------------------------------

%% 信道
%-----------------------------------------------------------
% 仅将发送信号直接相加，并添加白噪声
% PilotReceive = zeros(AntennaBS,FFTSize+CP_Long); %初始化
% DataReceive = zeros(AntennaBS,(FFTSize+CP_Short)*NumDataSymb); %初始化
% for i=1:NumUE
%     PilotReceive(1,:) = PilotReceive(1,:) + PilotOfdmModulated(i,:);
%     DataReceive(1,:) = DataReceive(1,:) + DataOfdmModulated(i,:);
% end
% for i=2:AntennaBS
%     PilotReceive(i,:) = PilotReceive(1,:);
%     DataReceive(i,:) = DataReceive(1,:);
% end
%-----------------------------------------------------------
% % 采用SCM信道模型
if iSlot == 1
   [H DELAYS BULK_par] = scm(Scmpar,Linkpar,Antpar);
else
   [H DELAYS BULK_par] = scm(Scmpar,Linkpar,Antpar,bulkpar);
end
bulkpar = BULK_par;

NumPathTaps = size(H,3);
PilotReceive = zeros(NumUE,FFTSize+CP_Long + NumPathTaps-1); %初始化
DataReceive = zeros(NumUE,(FFTSize+CP_Short)*NumDataSymb + NumPathTaps-1); %初始化
for nRx = 1:NumUE  %导频、数据经过信道
    for nTX = 1:AntennaBS
       
        PilotReceive(nRx,:) = PilotReceive(nRx,:) + conv(squeeze(H(nRx, 1, :, 1, nTX)), PilotOfdmModulated(nTX,:));
        DataReceive(nRx,:) = DataReceive(nRx,:) + conv(squeeze(H(nRx, 1, :, 1, nTX)), DataOfdmModulated(nTX,:));
       
    end
end
%-----------------------------------------------------------
% PilotReceive = awgn(PilotReceive,SNR,'measured');
% DataReceive = awgn(DataReceive,SNR,'measured');  

PilotReceive = PilotReceive(:,1:(FFTSize+CP_Long)); %去除掉由于信道时延扩展带来的数据长度的增加
DataReceive = DataReceive(:,1:((FFTSize+CP_Short)*NumDataSymb));  %去除掉由于信道时延扩展带来的数据长度的增加

%% 接收端（UE）
%-----------------------------------------------------------
% 去除循环前缀，OFDM解调，取出3168个有效子载波
RxFreqPilot = zeros(NumUE,NumSubcarriers);
RxFreqData = zeros(NumUE,NumSubcarriers*NumDataSymb);

RxFreqPilot = ofdm_demodulate(PilotReceive,FFTSize,NumSubcarriers,'Pilot');
RxFreqData = ofdm_demodulate(DataReceive,FFTSize,NumSubcarriers,'Data');
%-----------------------------------------------------------
% LS信道估计
H_FreqEstimate = LS_channel_estimation(RxFreqPilot,PilotTotal);

% %------------------------------------------------------------
% % 基于QR分解的LMMSE均衡
% W = lmmse_qr(H_FreqEstimate,AntennaBS,TotalUE,Sigama);
% NumSubBand = NumSubcarriers/TotalUE;
% DataRecover = zeros(TotalUE,size(RxFreqData,2));
% Index = 1;
% for i=1:size(RxFreqData,2)
%     DataRecover(:,i) = W{1,mod(Index-1,NumSubBand)+1}*RxFreqData(:,i);
%     if mod(i,TotalUE)==0
%         Index = Index + 1;
%     end
% end

%得到每个用户的信道矩阵
H_FreqEstimate_temp=zeros(NumUE,NumSubcarriers);

for n=1:NumUE
    j=1;
  for i=(UE_ID(n)+1):12:NumSubcarriers
    H_FreqEstimate_temp(n,j)=H_FreqEstimate(n,i);
    j=j+1;
   end
end

NumSubBand = NumSubcarriers/TotalUE;
DataRecover = zeros(NumUE,size(RxFreqData,2));
Index = 1;
for i=1:size(RxFreqData,2)
     DataRecover(:,i) = RxFreqData(:,i)./H_FreqEstimate_temp(:,mod(Index-1,NumSubBand)+1);
    if mod(i,TotalUE)==0
        Index = Index + 1;
    end
end


 ber_uplink=CalculateBER_sy(DataRecover,DataRaw,UE_ID,NumDataSymb,NumSubcarriers,Modulation,1);
 BER_total_uplink = BER_total_uplink+ber_uplink
end %for iFrame = 1:SimFrameNum

    figure(1)
for i=1:NumUE
subplot(3,4,i);
    plot(DataRecover(UE_ID(i)+1,:),'o');
%     legend('N_I_D^(^2^) = 0',NumUE)
    title('星座图',num2str(i));
end

% for i=1:NumUE
%     figure(i)
%     plot(DataRecover(i,:),'o');
%     xlim([-1,1]);
%     ylim([-1,1]);
%     title('星座图');
% end




